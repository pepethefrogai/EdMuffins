const menuToggle = document.getElementById('menuToggle');
const header = document.querySelector('.site-header');

if (menuToggle && header) {
  menuToggle.addEventListener('click', () => {
    header.classList.toggle('menu-open');
  });
}

const continueBtn = document.getElementById('continueBtn');
const paymentForm = document.getElementById('paymentForm');
const successMessage = document.getElementById('successMessage');
const copyWalletBtn = document.getElementById('copyWalletBtn');
const walletAddress = document.getElementById('walletAddress');

if (continueBtn && paymentForm) {
  continueBtn.addEventListener('click', () => {
    paymentForm.classList.remove('hidden');
    paymentForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}

if (copyWalletBtn && walletAddress) {
  copyWalletBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(walletAddress.value);
      copyWalletBtn.textContent = 'Copied';
      setTimeout(() => {
        copyWalletBtn.textContent = 'Copy';
      }, 1500);
    } catch (error) {
      copyWalletBtn.textContent = 'Copy failed';
      setTimeout(() => {
        copyWalletBtn.textContent = 'Copy';
      }, 1500);
    }
  });
}

if (paymentForm && successMessage) {
  paymentForm.addEventListener('submit', (event) => {
    event.preventDefault();
    paymentForm.classList.add('hidden');
    successMessage.classList.remove('hidden');
  });
}
